#include <iostream>
using namespace std;

int main() {
    cout << "3472 - 2355 = " << 3472 - 2355;
    cout << "2468 + 1234" << 2468 + 1234;
    cout << endl;
    cout << "2468 - 1234" << 2468 - 1234;
    cout << endl;
    cout << "2468 * 1234" << 2468 * 1234;
    cout << endl;
    cout << "2468 / 1234" << 2468 / 1234;
    cout << endl;
    return 0;
}

int main2() {
    int a = 8343, b = 6453;
    cout << "a - b = " << a - b << endl;
    string name = "Codelearn" << endl;
    int dob = 2019;
    cout << "Name: " << name << endl;
    cout << "Date of birth: " << dob << endl;
    double length = 7.5;
    double width = 3.8;
    cout << "Area = " << length * width << endl;
    long long a = 384847522, b = 988347273;
    cout << a * b << endl;
    return 0;
}
