#include <iostream>

int main(int argc, char **argv) {
    std::cout << "This is a test" << std::endl;
    return 0;
}
